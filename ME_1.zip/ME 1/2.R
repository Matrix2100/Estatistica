library(readxl)
dadosRAW <- read_excel("ME 1/dados_2.xlsx")
dadosRAW
dados = as.numeric(unlist(dadosRAW))

media = mean(dados)
mediana = median(dados)
dp = sd(dados)

quartis = quantile(dados)

#AMPLITUDE DE CLASSE
x_min = min(dados) -0.1
x_max = max(dados) +0.1
AT = x_max - x_min
N = length(dados)
K = ceiling(log(N)/log(2))
AC = (AT/K)
int_classes = seq(x_min,x_max,AC)

#(valores da freq_absoluta)
w = table( cut(dados,breaks= int_classes,right =FALSE))

#teste = as.numeric(w)
#teste

#para tabela de distribuição de frequencias 
#freq_absoluta = c(140,65,78,77,80,157,68,93,78,164)
freq_absoluta = as.numeric(w)
freq_relativa = prop.table(freq_absoluta)
freq_percentual = freq_relativa*100

#RESPOSTAS DA QUESTAO


#Media, mediana, desvio padrao
media
mediana
dp

#a
quartis

#tabela de destribuição de frequencia
data.frame(w,freq_relativa,freq_percentual)

# HISTOGRAMA
hist(dados, breaks=int_classes, col="blue", freq = TRUE)

# Pie Chart
pie(freq_percentual, labels = paste(names(w),freq_percentual,"%"), main="Frequencia")
